package com.domain.model;

public class User {

	private Integer UserID;
	private String UserName;

	public User() {

	}

	public User(Integer userID, String userName) {
		setUserID(userID);
		setUserName(userName);
	}

	public Integer getUserID() {
		return UserID;
	}

	public void setUserID(Integer userID) {
		UserID = userID;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

}
