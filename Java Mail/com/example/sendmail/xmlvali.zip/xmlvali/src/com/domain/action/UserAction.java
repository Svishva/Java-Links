package com.domain.action;

import com.domain.model.User;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	User user = new User();

	public String execute() {
		
		System.out.println("execute method invoked");
		
		return SUCCESS;
	}

}
