package com.action;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.bson.Document;

import com.google.gson.Gson;
import com.model.MedicineInvoice;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class DisplayInvoice extends ActionSupport{

	
	
	private static final long serialVersionUID = 8980733935103118379L;
	List<MedicineInvoice> medicineInvoiceList = new ArrayList<>();
	Gson gson = new Gson();
	//private String netAmount;
	public String execute() throws Exception{
		
		/*HttpServletRequest request =  ServletActionContext.getRequest();
		HttpSession session = request.getSession();*/
		 /*medicineInvoiceList =(List<MedicineInvoice>) ServletActionContext.getServletContext().getAttribute("medicineInvoiceList");
		 setMedicineInvoiceList(medicineInvoiceList);
		System.out.println(" size "+medicineInvoiceList.size());*/
		
		
		//setNetAmount((String)ActionContext.getContext().getSession().get("netAmount"));
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collectionInvoice = mc.getDatabase("d5").getCollection("MedicinesInvoice");	
		
		 String CustomerID = (String) ActionContext.getContext().getSession().get("CustomerID");
		
		 System.out.println("CustomerID"+CustomerID);
		 if((CustomerID != null)){
		 if( collectionInvoice.count() > 0 ){
		 try {
			
			
			//Sort the elements
			//MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
			
			 
			
			Document invoices = (Document) collectionInvoice.find(eq("CustomerID", Integer.parseInt(CustomerID))).first(); //.get("Details");
			
			 System.out.println(" display invoice = "+invoices.toJson().toString());
			 
			 @SuppressWarnings("unchecked")
			List<Document> bill = (List<Document>)  invoices.get("Details");
			 
			 System.out.println(bill);
			 
			 ListIterator<Document> itr = bill.listIterator();
			 
			 while(itr.hasNext()){
				 
				 medicineInvoiceList.add(gson.fromJson(itr.next().toJson(), MedicineInvoice.class));
				 
			 }
			 
		//	List<MedicineInvoice> details = (List<MedicineInvoice>) invoices.get("Details");
		//	 System.out.println(details);
			 
			 /*if(details != null){
			 System.out.println(details.toString());
			
			 ListIterator<Document> itr = details.listIterator(); 
			 while(itr.hasNext()){
				 
				 medicineInvoiceList.add(gson.fromJson(itr.next().toJson(), MedicineInvoice.class));
			 }
			 }else{
				 
				 System.out.println(" details == null");
				 
			 }*/
			/* while(cursor.hasNext()){
				 
				 doc = (Document) cursor.next().get("Details");
			 
			System.out.println("ID"+CustomerID);
			System.out.println(doc.toJson().toString());
			 medicineObject = gson.fromJson(doc.toJson(), MedicineInvoice.class);
			    System.out.println(" get all medi"+medicineObject.toString());
			    medicineInvoiceList.add(medicineObject);
			
			 }*/
			/* if(cursor.hasNext()){
				
				try {
			    while (cursor.hasNext()) {
			       doc =cursor.next();
			    medicineObject = gson.fromJson(doc.toJson(), MedicineInvoice.class);
			    System.out.println(" get all medi"+medicineObject.toString());
			    medicineInvoiceList.add(medicineObject);
			    }
			} finally {
				System.out.println(medicineInvoiceList);
			    cursor.close();
			}
			}*/
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}finally{
			try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
		}
		 }else{
			 // DB has no records
		 }
		 }
		
		return SUCCESS;
		
		
	}

	public List<MedicineInvoice> getMedicineInvoiceList() {
		return medicineInvoiceList;
	}

	public void setMedicineInvoiceList(List<MedicineInvoice> medicineInvoiceList) {
		this.medicineInvoiceList = medicineInvoiceList;
	}

	/*public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}*/
	
	
	
}
