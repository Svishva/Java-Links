package com.domain.action;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.opensymphony.xwork2.Action;

public class AutoComp implements Action 
{
    public List<String> medicineNames = new ArrayList<String>();
   
   

	Gson gson = new Gson();


    public String execute() 
    {
    	
    	System.out.println(" AutoComp execute() executed");
    	MongoClient mc = new MongoClient( "localhost" , 27017 );
    	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
    	
    	
    	 if(collection.count() > 0 ){
    	 try {
    		
    		
    		
    		MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
    		
    		if(cursor.hasNext()){
    			
    			try {
    		    while (cursor.hasNext()) {
    		    	 
    		       
    		       medicineNames.add((String) cursor.next().get("medicineName"));
    		   
    		    }
    		} finally {
    			System.out.println(medicineNames);
    		    cursor.close();
    		}
    		}
    		
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    		System.err.println(e.getMessage());
    	}finally{
    		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
    	}
    	 }else{
    		 
    	 }
            return SUCCESS;
    }

    /*public void getMedicineNamesFromDB() 
    {
    	
    	
    	
    	MongoClient mc = new MongoClient( "localhost" , 27017 );
    	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
    	
    	
    	 if(collection.count() > 0 ){
    	 try {
    		
    		
    		
    		MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
    		
    		if(cursor.hasNext()){
    			
    			try {
    		    while (cursor.hasNext()) {
    		    	 
    		       
    		       medicineNames.add((String) cursor.next().get("medicineName"));
    		   
    		    }
    		} finally {
    			System.out.println(medicineNames);
    		    cursor.close();
    		}
    		}
    		
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    		System.err.println(e.getMessage());
    	}finally{
    		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
    	}
    	 }else{
    		 
    	 }
            
    }*/

    
    public List<String> getMedicineNames() {
		return medicineNames;
	}


	public void setMedicineNames(List<String> medicineNames) {
		this.medicineNames = medicineNames;
	}

    

	
       
}