package com.domain.action;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class SalesPageInterceptor implements Interceptor{

	
	private static final long serialVersionUID = -2742309269987201152L;

	@Override
	public void destroy() {
		
		
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String intercept(ActionInvocation arg0) throws Exception {
		
		System.out.println("SalesPageInterceptor interceptor executed");
		
		Integer i = 1;
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collectionInvoice = mc.getDatabase("d5").getCollection("MedicinesInvoice");
		try {
			if(collectionInvoice.count() == 0 )
			{
				ActionContext.getContext().getSession().put("CustomerID", "1");
				return "success";
			}else{
				MongoCursor<Document> cursor= collectionInvoice.find().sort(new Document("CustomerID",1)).iterator();
			while (cursor.hasNext()) {

				System.out.println(" CID value "+i);
				if(cursor.next().get("CustomerID").equals(i)){
					i++;
				}else{
					
					cursor.close();
					break;
				}
			}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{ if(mc != null) {mc.close(); }} catch(Exception e ){e.printStackTrace();}
		}

		ActionContext.getContext().getSession().put("CustomerID", i.toString());
		
		
		return "success";
	}

}
