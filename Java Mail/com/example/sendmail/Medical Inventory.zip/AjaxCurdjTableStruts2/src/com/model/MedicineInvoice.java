package com.model;

public class MedicineInvoice {

	
	
	private String medicineName;
	private String medicineQuantity;
	private String medicinePerCost;
	private String medicineTotalCost;
	private String netTotal;

	/* Functions */

	@Override
	public String toString() {
		return "MedicineInvoice [medicineName=" + medicineName + ", medicineQuantity=" + medicineQuantity
				+ ", medicinePerCost=" + medicinePerCost + ", medicineTotalCost=" + medicineTotalCost + "]";
	}

	/* Constructors */

	public MedicineInvoice() {
		super();
	}

	
	public MedicineInvoice(String medicineName, String medicineQuantity, String medicinePerCost,
			String medicineTotalCost) {
		super();
		this.medicineName = medicineName;
		this.medicineQuantity = medicineQuantity;
		this.medicinePerCost = medicinePerCost;
		this.medicineTotalCost = medicineTotalCost;
	}
	
	
	/* Getters and Setters */

	

	public String getMedicinePerCost() {
		return medicinePerCost;
	}

	public void setMedicinePerCost(String medicinePerCost) {
		this.medicinePerCost = medicinePerCost;
	}

	public String getNetTotal() {
		return netTotal;
	}

	public void setNetTotal(String netTotal) {
		this.netTotal = netTotal;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	public String getMedicineQuantity() {
		return medicineQuantity;
	}

	public void setMedicineQuantity(String medicineQuantity) {
		this.medicineQuantity = medicineQuantity;
	}

	public String getMedicineTotalCost() {
		return medicineTotalCost;
	}

	public void setMedicineTotalCost(String medicineTotalCost) {
		this.medicineTotalCost = medicineTotalCost;
	}

	

}
