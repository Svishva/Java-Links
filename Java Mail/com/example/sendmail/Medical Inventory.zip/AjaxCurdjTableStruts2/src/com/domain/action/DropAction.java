package com.domain.action;

import static com.mongodb.client.model.Filters.eq;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bson.Document;

import com.google.gson.Gson;
import com.model.Medicine;
import com.model.MedicineInvoice;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class DropAction extends ActionSupport {
	
	
	private static final long serialVersionUID = 1L;
	private List<String> dataList = null;
	private String medicineName;
	private String medicineQuantity;
	private String medicineAvailable;
	private String medicineCostPerUnit;
	private String percost;
	private String medicineUnitCost;
	private String netAmount;
	
	List<MedicineInvoice> medicineInvoiceList = new ArrayList<>();
	

	Gson gson = new Gson();
	

	@Override
	public String execute() throws Exception {
		
		
		
		System.out.println("medicineName = \t"+medicineName);
		System.out.println("medicineQuantity = \t"+medicineQuantity);

		return SUCCESS;
	}

	
	public String getAvailable() throws Exception{
		
		List<Medicine> medicineObjects = new ArrayList<Medicine>();
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
		 
		 if(collection.count() > 0 ){
		 try {
			
			System.out.println("medicineName ="+medicineName +"medicineQuantity = "+medicineQuantity );
			
			//MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
			
			 MongoCursor<Document> cursor = null;				
				try {
					 
					
					
					if(medicineQuantity.length() >0 && medicineName.length() >1){
					
					cursor = collection.find(new Document("medicineName",medicineName)).iterator();
					 if(cursor.hasNext()){
						 Document doc =cursor.next();
						 cursor.close();
						BigDecimal quantityDB = new BigDecimal((String)doc.get("medicineQuantity"));
						BigDecimal costDB = new BigDecimal((String)doc.get("medicineCostPerUnit"));
						
						BigDecimal quantitySales = new BigDecimal(medicineQuantity);
						
						setMedicineAvailable(quantityDB.toString());
						setMedicineUnitCost(costDB.toString());
						System.out.println("comp val"+quantityDB.compareTo(quantitySales));

						if(quantityDB.compareTo(quantitySales)== -1){
							
							setPercost(quantityDB+" is available");
							
						}else{

						if(quantityDB.compareTo(BigDecimal.ZERO) == 0){
							
							setPercost("No Stock Available");
							
						}else{
							
							BigDecimal total = costDB.multiply(quantitySales);
							setPercost(total.toString());
						}
						
						}
					 }else{
						 
						 setMedicineAvailable("");
						 setPercost("No Stock Available");
					 }
					
					}
					
			} finally {
				System.out.println(medicineObjects);
			    
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}finally{
			try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
		}
		 }else{
			 
			 
			 setMedicineAvailable(" Database has no records");
		 }
		
		
		
		return SUCCESS;
		
		
	}
	
	
	
	public String postDatas() throws Exception{
		
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
		MongoCollection<Document> collectionInvoice = mc.getDatabase("d5").getCollection("MedicinesInvoice");	

		
		
	try{	
		if(medicineName != null && medicineName.length() > 2 && medicineQuantity != null && medicineQuantity.length() > 0 ){
		
		System.out.println("post" +medicineName);
		
		
			Integer quantity = Integer.parseInt(medicineQuantity);
			Integer available = Integer.parseInt(medicineAvailable);
			if(available >= quantity){
				System.out.println("passed condition");
			Integer newQuantity = available- quantity;
				
				collection.updateOne(eq("medicineName", medicineName), new Document("$set", new Document("medicineQuantity", newQuantity.toString())));
				
				String CustomerID =	(String) ActionContext.getContext().getSession().get("CustomerID");
				 if(CustomerID != null){
					 
				 
				
				if(collectionInvoice.find(eq("CustomerID", Integer.parseInt(CustomerID))).iterator().hasNext()){
				
				
					
					/*@SuppressWarnings("unchecked")
					Document docs = (Document) cursor.next().get("Details");
					docs. append(Document.parse(gson.toJson(new MedicineInvoice(medicineName,medicineQuantity,medicineUnitCost,percost))));*/
					
				Document	doc =Document.parse(gson.toJson(new MedicineInvoice(medicineName,medicineQuantity,medicineUnitCost,percost)));
				collectionInvoice.updateOne(eq("CustomerID", Integer.parseInt(CustomerID)), new Document("$push", new Document("Details", doc)));

					
					
				}else{
					
					ActionContext.getContext().getSession().put("netAmount", netAmount);
					netAmount = netAmount.replaceAll("[A-Za-z :]", "");
				collectionInvoice.insertOne(new Document("CustomerID",Integer.parseInt(CustomerID)).append("Net Cost", netAmount).append("Details",Arrays.asList( Document.parse(gson.toJson(new MedicineInvoice(medicineName,medicineQuantity,medicineUnitCost,percost))))));
				
				
				
				}
				
				 }

				
			}
		//}
		}
		return SUCCESS;
	}
	catch(Exception e){
		e.printStackTrace();
		return ERROR;
	}finally{
	
	 /*, arg1);
		session = request.getSession();
		session.put("medicineInvoiceList", medicineInvoiceList);*/
		
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
		
		
		
	}
	


	
	
	
	
	
	
	
	

	
	
	
	/*private String getCustomerID() {
		
		Integer i = 1;
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("MedicinesInvoice");
		try {
			if(collection.count() == 0 )
			{
				return "1";
			}else{
				MongoCursor<Document> cursor= collection.find().sort(new BasicDBObject("CustomerID",1)).iterator();;
			while (cursor.hasNext()) {

				System.out.println(" I value "+i);
				if(cursor.next().get("CustomerID").equals(i.toString())){
					i++;
				}else{
					
					cursor.close();
					break;
				}
			}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{ if(mc != null) {mc.close(); }} catch(Exception e ){e.printStackTrace();}
		}

		return i.toString();
	}
*/
	
	/*	Getter and Setters*/

	public List<String> getDataList() {
		return dataList;
	}

	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}


	public String getMedicineQuantity() {
		return medicineQuantity;
	}


	public void setMedicineQuantity(String medicineQuantity) {
		this.medicineQuantity = medicineQuantity;
	}


	public String getMedicineAvailable() {
		return medicineAvailable;
	}


	public void setMedicineAvailable(String medicineAvailable) {
		this.medicineAvailable = medicineAvailable;
	}


	public String getMedicineCostPerUnit() {
		return medicineCostPerUnit;
	}


	public void setMedicineCostPerUnit(String medicineCostPerUnit) {
		this.medicineCostPerUnit = medicineCostPerUnit;
	}


	public String getPercost() {
		return percost;
	}


	public void setPercost(String percost) {
		this.percost = percost;
	}


	public String getMedicineUnitCost() {
		return medicineUnitCost;
	}


	public void setMedicineUnitCost(String medicineUnitCost) {
		this.medicineUnitCost = medicineUnitCost;
	}
	
	public List<MedicineInvoice> getMedicineInvoiceList() {
		return medicineInvoiceList;
	}


	public void setMedicineInvoiceList(List<MedicineInvoice> medicineInvoiceList) {
		this.medicineInvoiceList = medicineInvoiceList;
	}


	public String getNetAmount() {
		return netAmount;
	}


	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

}