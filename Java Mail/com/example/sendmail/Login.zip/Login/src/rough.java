

public class rough {

	/*
	 * 
	 * // // // // List<String> names = new ArrayList<String>(); 
	 * //
	 * names.add("i an Mac"); // names.add("i am iPhone"); //
	 * names.add("i am iPod"); //
	 * ActionContext.getContext().getApplication().put("names", names); //
	 * 
	 * 
	 * 
	 * <s:select list="#application.names" label="states"
	 * name="states"></s:select>
	 */

}
