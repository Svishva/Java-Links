package com.domain.dao.implementation.mongodb;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

public final class MongoDBUtilities {
	
	private static MongoClient mongoClient;
	private static MongoCollection<Document> collection;
	
	
 private static final  MongoClient getInstance(){
		 
		 try{
		 
			   mongoClient = new MongoClient( "localhost" , 27017 );
			
			System.out.println("Form Database getInstance() executed");
			return mongoClient;
		 }
		 catch(com.mongodb.MongoSocketOpenException e){
			 System.out.println(" MongoDBUtilities.java getInstance (MongoSocketOpenException)");
			 e.printStackTrace();
			 return null;
		 }
		 
		 catch(Exception e){
			 System.out.println(" MongoDBUtilities.java getInstance (exception)");
			 e.printStackTrace();
			 return null;
		 }
	 }
	
	
 	/*
 	 * Get all states from database based on parameter
 	 * 
 	 * @param String CountryName 
 	 * 
 	 * @result LinkedHashMap<String,String> all states of CountryName
 	 * 
 	 */
	public static Map<String,String> formCountry(String countryname) throws Exception{
		
		try{
			
			mongoClient = getInstance();
			
			//if Db is notnull, do operation
			if(mongoClient != null){
			
				//Db is connected, do Operations
				//initailize collection
			collection = mongoClient.getDatabase("Domain").getCollection("DomainUtilities");
			
			if((Long)collection.count() ==0) {
				System.out.println("Collection has no Records");
				return null;
			}else{
			
				BasicDBObject query = new BasicDBObject("id",countryname );
		@SuppressWarnings("unchecked")
		Map<String,String> map = (Map<String,String>)collection.find(query).first().get(countryname+"States");
		
		
					return map;
			
			}
		
		}else{
			
			//Handle, Db is null
			
			System.out.println(" Problem in Connnecting DB Database not Connected");
			return null;
		}
		}
		catch(com.mongodb.MongoTimeoutException e){
			 System.out.println(" MongoDBUtilities.java getInstance (MongoTimeoutException)");
			 System.out.println(" Database is not responding");
			 e.printStackTrace();
			 return null;
		 }
		catch(Exception e){
			 System.out.println(" MongoDBUtilities.java  loginUser(exception:)"+ e.getClass());
			e.printStackTrace();
			
		}
		finally{
			if(mongoClient != null){
			mongoClient.close();
			
			}
			}
		return null;
		
	}



	public static List<String> getAllCountryNames() {
		
try{
			
			mongoClient = getInstance();
			
			//if Db is notnull, do operation
			if(mongoClient != null){
			
				//Db is connected, do Operations
				//initailize collection
			collection = mongoClient.getDatabase("Domain").getCollection("DomainUtilities");
			
			if((Long)collection.count() ==0) {
				System.out.println("Collection has no Records");
				return null;
			}else{
			
				BasicDBObject query = new BasicDBObject("id", "countrynames");
		@SuppressWarnings("unchecked")
		List<String> list = (ArrayList<String>)collection.find(query).first().get("countrynames");

					return list;
			
			}
		
		}else{
			
			//Handle, Db is null
			
			System.out.println(" Problem in Connnecting DB Database not Connected");
			
		}
		}
		catch(com.mongodb.MongoTimeoutException e){
			 System.out.println(" MongoDBUtilities.java getInstance (MongoTimeoutException)");
			 System.out.println(" Database is not responding");
			 e.printStackTrace();
			 return null;
		 }
		catch(Exception e){
			 System.out.println(" MongoDBUtilities.java  loginUser(exception:)"+ e.getClass());
			e.printStackTrace();
			
		}
		finally{
			if(mongoClient != null){
			mongoClient.close();
			
			}
			}
		return null;
	}


	public static List<String> getAllUserNames() {

try{
	List<String> list ;
			
			mongoClient = getInstance();
				//initailize collection
			collection = mongoClient.getDatabase("Domain").getCollection("DomainUtilities");
			//Document doc = new Document();
			FindIterable<Document> res=collection.find(new Document("UserName",1));
			while(res.iterator().hasNext()){
				//list.add(res);
			}
		
}
catch(Exception e){
	e.printStackTrace();
}finally{
	mongoClient.close();
}
		
		return null;
	}


}
