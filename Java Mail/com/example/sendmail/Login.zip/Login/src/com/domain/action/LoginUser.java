package com.domain.action;

import java.util.Map;

import com.domain.beans.User;
import com.domain.dao.implementation.mongodb.UserDAOImpMongoDB;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * Acts as a controller to handle actions related to login a user.
 *
 */

public class LoginUser extends ActionSupport {

	private static final long serialVersionUID = 5612918085770170571L;
	private String UserName;
	private String UserPassword;
	UserDAOImpMongoDB dbObj = new UserDAOImpMongoDB();

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public String execute() throws Exception {

		
		if(dbObj.loginUser(UserName, UserPassword) == 1 ){
			

			System.out.println("Execute method executed");
			User temp = new User(UserName, UserPassword);

			temp.setLoggeduser(temp);

			System.out.println(temp.toString());
			ActionContext.getContext().getSession().put("User", UserName);

			return SUCCESS;
			
			
		}else{
			
			return "loginfailed";
			
		}
		


	}

	public void validate() {

		System.out.println("validate method executed");

		if (UserName == null || UserName.length() <= 4) {

			addFieldError("UserName",
					"First name is required and Length should be atleast five");

		}

		if (UserPassword == null || UserPassword.length() <= 6) {

			addFieldError("UserPassword",
					"UserPassword is required and Length should be atleast Seven");

		}
	}

	public static void isNewSession() throws Exception {

		//String flag = "";
		Map<?, ?> session = (Map<?, ?>) ActionContext.getContext().getSession();
		String User = (String) session.get("User");

		if (User == null) {

			System.out.println(" isNewSession if  ");
			ActionContext.getContext().getSession().put("UserValue", false);
			// return SUCCESS;
			//flag = "success";

		} else {

			System.out.println(" isNewSession else");
			ActionContext.getContext().getSession().put("UserValue", true);

			
			// return "failure";
			//flag = "loginpage";
		}

		//return flag;

	}

}
