package com.domain.action;

import java.util.LinkedHashMap;
import java.util.Map;

import com.domain.dao.implementation.mongodb.MongoDBUtilities;
import com.opensymphony.xwork2.ActionSupport;

public class FormDataAction extends ActionSupport {
	
	
	

	private static final long serialVersionUID = 8907570278154698432L;

	private Map<String, String> stateMap = new LinkedHashMap<String, String>();

	// Parameter from Jquery
	private String countryName;

	/*
	 * call Database to get all states of a particular Country
	 * 
	 *  @param CountryName 
	 *  
	 *  @return Map<String,String> all states of Country Name
	 *  Map Key & Value are State Name
	 *  ("Tamil Nadu", "Tamil Nadu") 
	 */
	public String formCountryAction() throws Exception {

		System.out.println("formCountryAction executed \t"+ countryName);
		stateMap = new LinkedHashMap<String, String>(
				MongoDBUtilities.formCountry(countryName));
		if(stateMap == null ){
			System.out.println("FormDataAction.java formCountryAction stateMap is null ");
		}
		// stateMap = MongoDBUtilities.formCountry(countryName);

		return "success";
	}

	public Map<String, String> getStateMap() {
		return stateMap;
	}

	public void setStateMap(Map<String, String> stateMap) {
		this.stateMap = stateMap;
	}


	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	

}
