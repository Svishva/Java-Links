package com.domain.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class RegisterAI implements Interceptor{

	
	private static final long serialVersionUID = 1310274813396459639L;

	@Override
	public void destroy() {
		
	}

	@Override
	public void init() {
		
	}

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {

		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		session.setAttribute("UserValue", false);

		if (invocation.invoke().equals("success")) {

			System.out.println(" Register INSIDE SUCCESS");
			session.setAttribute("UserValue", true);
			// set session for five minutes
			session.setMaxInactiveInterval(10);
			return "success";

		}else{
			
			return "failure";
		}
	
		
		
		
	}
	
	

}
