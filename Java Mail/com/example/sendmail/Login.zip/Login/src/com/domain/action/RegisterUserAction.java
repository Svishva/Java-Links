package com.domain.action;

import com.domain.beans.User;
import com.domain.dao.implementation.mongodb.UserDAOImpMongoDB;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class RegisterUserAction extends ActionSupport {

	
	private static final long serialVersionUID = -811799025162586127L;
	private String UserName;
	private String UserPassword;
	private String UserGender;
	private String UserHobbies;
	private String UserNationality;
	private String UserEducation;
	private String UserEducation2;

	
	
	
	public String getUserGender() {
		return UserGender;
	}

	public void setUserGender(String userGender) {
		UserGender = userGender;
	}

	public String getUserHobbies() {
		return UserHobbies;
	}

	public void setUserHobbies(String userHobbies) {
		UserHobbies = userHobbies;
	}

	public String getUserNationality() {
		return UserNationality;
	}

	public void setUserNationality(String userNationality) {
		UserNationality = userNationality;
	}

	public String getEducation2() {
		return UserEducation2;
	}

	public void setEducation2(String education2) {
		UserEducation2 = education2;
	}



	UserDAOImpMongoDB dbObj2 = new UserDAOImpMongoDB();

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public String execute() throws Exception {

		User temp = new User(UserName, UserPassword,UserGender,UserHobbies,UserNationality,UserEducation,UserEducation2);
		
		if (dbObj2.createUser(temp) == 1) {

			System.out.println("Register Execute method executed");

			temp.setLoggeduser(temp);

			System.out.println(temp.toString());
			ActionContext.getContext().getSession().replace("User", UserName);
			ActionContext.getContext().getSession().replace("UserValue",true);
			return SUCCESS;

		} else {

			return "loginfailed";

		}

	}
	
	
	
	public void validate() {

		System.out.println("validate method executed");

		if (UserName == null || UserName.length() <= 4) {

			addFieldError("UserName",
					"\tFirst name is required and Length should be atleast five");

		}

		if (UserPassword == null || UserPassword.length() <= 6) {

			addFieldError("UserPassword",
					"\tUserPassword is required and Length should be atleast Seven");

		}
		
		if(UserGender == null || UserGender.length() == 0){
			
			addFieldError("UserGender",
					"Please select your gender");
		}
		
		if(UserHobbies == null || UserHobbies.length() == 0){
			
			addFieldError("UserHobbies",
					"Please select any one Hobbies");
		}
		
		if(UserNationality == null || UserNationality.equals("select")){
			
			addFieldError("UserNationality",
					"Please select your Nationality");
		}
		
		if(UserEducation == null || UserEducation.equals("select")){
			
			addFieldError("UserEducation",
					"Please select your Education");
			}
		
		if(UserEducation2 == null || UserEducation2.equals("select")){
			
			addFieldError("UserEducation2",
					"Please select your Education");
			}
		
	}
	

	public String getEducation() {
		return UserEducation;
	}

	public void setEducation(String education) {
		UserEducation = education;
	}
	
	
	

}
