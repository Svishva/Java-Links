package com.domain.action;

import com.domain.beans.User;
import com.domain.dao.implementation.mongodb.UserDAOImpMongoDB;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class RegisterUserAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -811799025162586127L;
	private String UserName;
	private String UserPassword;
	UserDAOImpMongoDB dbObj2 = new UserDAOImpMongoDB();

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public String execute() throws Exception {

		if (dbObj2.createUser(UserName, UserPassword) == 1) {

			System.out.println("Register Execute method executed");
			User temp = new User(UserName, UserPassword);

			temp.setLoggeduser(temp);

			System.out.println(temp.toString());
			ActionContext.getContext().getSession().put("User", UserName);

			return SUCCESS;

		} else {

			return "loginfailed";

		}

	}
	
	
	
	public void validate() {

		System.out.println("validate method executed");

		if (UserName == null || UserName.length() <= 4) {

			addFieldError("UserName",
					"\tFirst name is required and Length should be atleast five");

		}

		if (UserPassword == null || UserPassword.length() <= 6) {

			addFieldError("UserPassword",
					"\tUserPassword is required and Length should be atleast Seven");

		}
	}
	
	
	

}
