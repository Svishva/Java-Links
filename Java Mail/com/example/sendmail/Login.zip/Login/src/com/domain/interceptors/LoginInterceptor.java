package com.domain.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class LoginInterceptor implements Interceptor {

	private static final long serialVersionUID = -1124655400275179510L;

	@Override
	public void destroy() {

	}

	@Override
	public void init() {

	}

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {

		HttpServletRequest request = ServletActionContext.getRequest();

		HttpSession session = request.getSession();
		System.out.println(" intercept executed");
		
		if (invocation.invoke().equals("success")) {

			System.out.println(" INSIDE SUCCESS");
			
			// set session for five minutes
			session.setMaxInactiveInterval(10);
			return "success";

		}

		System.out.println(" intercept executed after calling action");

		return null;
	}

}
