package com.domain.dao.implementation.mongodb;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.domain.beans.User;
import com.domain.dao.implementation.mongodb.dbconnect.DatabaseMongoDB;

import org.bson.Document;

public class UserDAOImpMongoDB {
	
	private MongoClient mongoClient;
	private MongoCollection<Document> collection;
	
	
	/*
	 * Private Constructor to avoid Object Creation
	 */
	/*private UserDAOImpMongoDB(){
		
	}*/
	
	
	
	/*
	 * To get Instance from MongoDatabase
	 * 
	 * @return instance of MongoClient
	 * 
	 */
	 private final  MongoClient getInstance(){
		 
		 try{
		 
			   mongoClient = new MongoClient( "localhost" , 27017 );
			
			System.out.println("Form Database getInstance() executed");
			return mongoClient;
		 }
		 catch(com.mongodb.MongoSocketOpenException e){
			 System.out.println(" UserDAOImpMongoDB.java getInstance (MongoSocketOpenException)");
			 e.printStackTrace();
			 return null;
		 }
		 
		 catch(Exception e){
			 System.out.println(" UserDAOImpMongoDB.java getInstance (exception)");
			 e.printStackTrace();
			 return null;
		 }
	 }
	 
	 
/*	 
	 private final MongoCollection<Document> getColection(){
		 
		 try{
			 getInstance().getDatabase("Domain").getCollection("DomainUtilities");
		 }
		 catch(Exception e){
			 e.printStackTrace();
		 }
		return null;
		 
		 
	 }
	*/
	
	
	
	public Integer loginUser(String UserName, String UserPassword) throws Exception{
		
		try{
			
		//	getInstance();
		//collection = mongoClient.getDatabase("Domain").getCollection("DomainUtilities");
			mongoClient = getInstance();
			
		if(mongoClient != null){
			
			collection = mongoClient.getDatabase("Domain").getCollection("DomainUtilities");
			
			if((Long)collection.count() ==0) {
				System.out.println("Collection has no Records");
				return 0;
			}else{
			
			BasicDBObject query = new BasicDBObject("UserName", UserName).append(
					"UserPassword", UserPassword);

			if (collection.find(query).iterator().hasNext()) {
				
				System.out.println(" User entered correct Login details ");
				return 1;
			
		}
			}
		
		}else{
			
			System.out.println(" Problem in Connnecting DB Database not Connected");
		}
		}
		catch(com.mongodb.MongoTimeoutException e){
			 System.out.println(" UserDAOImpMongoDB.java getInstance (MongoTimeoutException)");
			 System.out.println(" Database is not responding");
			 e.printStackTrace();
			 return null;
		 }
		catch(Exception e){
			 System.out.println(" UserDAOImpMongoDB.java  loginUser(exception:)"+ e.getClass());
			e.printStackTrace();
			
		}
		finally{
			if(mongoClient != null){
			mongoClient.close();
			
			}
			}
		return 0;
		
	}


	public int createUser(User loggedUser) throws Exception {
		
		try{
			
			//	getInstance();
			//collection = mongoClient.getDatabase("Domain").getCollection("DomainUtilities");
				mongoClient = getInstance();
				collection = mongoClient.getDatabase("Domain").getCollection("DomainUtilities");
			if(collection != null || (Long)collection.count() != null){
				
				if((Long)collection.count() ==0) {
					System.out.println("Collection has no Records");
					return 0;
				}else{
				
		BasicDBObject query = new BasicDBObject("UserName", loggedUser.getUserName()).append(
				"UserPassword", loggedUser.getUserPassword());
		
		System.out.println(loggedUser.toString());
		
		if (collection.find(query).iterator().hasNext()) {
			
			return 0;
		}else{
			
			Document doc = new Document("UserName", loggedUser.getUserName())
            .append("UserPassword",loggedUser.getUserPassword())
            .append("UserGender",loggedUser.getUserGender())
            .append("UserNationality",loggedUser.getUserNationality())
            .append("UserHobbies",loggedUser.getUserHobbies())
            .append("UserEducation",loggedUser.getUserEducation())
            .append("UserEducation2",loggedUser.getUserEducation2());
			
			collection.insertOne(doc);
			
			return 1;
		}
		
				}
	
	}

}
		catch(Exception e){
			e.printStackTrace();
		}finally{
			if(mongoClient != null){
			mongoClient.close();
			
			}
			}
		return 0;
			
		}
}
