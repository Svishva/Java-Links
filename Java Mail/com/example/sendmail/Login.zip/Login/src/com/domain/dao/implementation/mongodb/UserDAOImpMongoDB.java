package com.domain.dao.implementation.mongodb;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.domain.dao.implementation.mongodb.dbconnect.DatabaseMongoDB;

import org.bson.Document;

public class UserDAOImpMongoDB {
	
	private final MongoCollection<Document> collection = DatabaseMongoDB.getInstance();
	
	
	public Integer loginUser(String UserName, String UserPassword) throws Exception{
		
		
		
		BasicDBObject query = new BasicDBObject("UserName", UserName).append(
				"UserPassword", UserPassword);

		if (collection.find(query).iterator().hasNext()) {
			
			return 1;
		}else{
			
			return 0;
		}
		
		
		
		
	}


	public int createUser(String UserName, String UserPassword) throws Exception {
		
		
		BasicDBObject query = new BasicDBObject("UserName", UserName).append(
				"UserPassword", UserPassword);
		
		if (collection.find(query).iterator().hasNext()) {
			
			return 0;
		}else{
			
			Document doc = new Document("UserName", UserName)
            .append("UserPassword", UserPassword);
			collection.insertOne(doc);
			
			
			return 1;
		}
		
	
	}

}
