package com.domain.interceptors;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.domain.dao.implementation.mongodb.MongoDBUtilities;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class RegisterPageInterceptor implements Interceptor {

	private static final long serialVersionUID = 8007105841249356010L;

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public String intercept(ActionInvocation arg0) throws Exception {

		/*List<String> country = new ArrayList<String>();

		country.add("Select");
		country.add("India");
		country.add("US");*/
		List<String> list =(ArrayList<String>) MongoDBUtilities.getAllCountryNames();
		
		HttpSession session = ServletActionContext.getRequest().getSession();
		if( list != null && list.size() != 0){
		session.setAttribute("Listofcountries", list);
		}
		return "success";
	}
}
