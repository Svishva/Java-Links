package com.domain.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class LoginPageInterceptor implements Interceptor{

	
	private static final long serialVersionUID = -7903685909479736484L;

	@Override
	public void destroy() {
		
	}

	@Override
	public void init() {
		
	}

	@Override
	public String intercept(ActionInvocation arg) throws Exception {
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();

		
		if(session.isNew()){
			
			System.out.println(" LoginPageInterceptor (session is new)");
			return "loginpage";
			
		}
		
		if(session.getAttribute("User") == null ){
			
			System.out.println(" LoginPageInterceptor (User is null)");
			return "loginpage";
			
		}else{
			
			
			
			
			
			System.out.println(" LoginPageInterceptor  (return login-success)");
			return "login-success";
		}
		
		
	}

}
