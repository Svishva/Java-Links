package com.domain.beans;

public class User {

	private String UserName;
	private String UserPassword;
	private String UserGender;
	private String UserHobbies;
	private String UserNationality;
	private String UserEducation;
	private String UserEducation2;
	private User loggeduser;

	/*
	 * User Bean Constructors
	 */
	public User() {

	}

	public User(String userName, String userPassword, String userGender,
			String userHobbies, String userNationality, String education,
			String education2) {

		UserName = userName;
		UserPassword = userPassword;
		UserGender = userGender;
		UserHobbies = userHobbies;
		UserNationality = userNationality;
		UserEducation = education;
		UserEducation2 = education2;

	}

	public User(String userName2, String userPassword2) {

		this.UserName = userName2;
		this.UserPassword = userName2;

	}

	
	/*
	 * Overrided method toString()
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "User [UserName=" + UserName + ", UserPassword=" + UserPassword
				+ ", UserGender=" + UserGender + ", UserHobbies=" + UserHobbies
				+ ", UserNationality=" + UserNationality + ", UserEducation="
				+ UserEducation + ", UserEducation2=" + UserEducation2 + "]";
	}
	

	/*
	 * User Bean Getter and Setters
	 */
	public String getUserNationality() {
		return UserNationality;
	}

	public void setUserNationality(String userNationality) {
		UserNationality = userNationality;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public User getLoggeduser() {
		return loggeduser;
	}

	public void setLoggeduser(User loggeduser) {
		this.loggeduser = loggeduser;
	}

	public String getUserGender() {
		return UserGender;
	}

	public void setUserGender(String userGender) {
		UserGender = userGender;
	}

	public String getUserHobbies() {
		return UserHobbies;
	}

	public void setUserHobbies(String userHobbies) {
		UserHobbies = userHobbies;
	}

	public String getUserEducation() {
		return UserEducation;
	}

	public void setUserEducation(String userEducation) {
		UserEducation = userEducation;
	}

	public String getUserEducation2() {
		return UserEducation2;
	}

	public void setUserEducation2(String userEducation2) {
		UserEducation2 = userEducation2;
	}

}
