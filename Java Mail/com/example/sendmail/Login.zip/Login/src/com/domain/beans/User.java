package com.domain.beans;

public class User {
	
	private String UserName;
	private String UserPassword;
	
	private User loggeduser;
	
	public User(){
		
		
	}
	
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserPassword() {
		return UserPassword;
	}
	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}
	
	
	@Override
	public String toString() {
		return "User [UserName=" + UserName + ", UserPassword=" + UserPassword
				+ "]";
	}
	
	
	public User(String userName, String userPassword) {

		UserName = userName;
		UserPassword = userPassword;
	}

	public User getLoggeduser() {
		return loggeduser;
	}

	public void setLoggeduser(User loggeduser) {
		this.loggeduser = loggeduser;
	}

	

}
