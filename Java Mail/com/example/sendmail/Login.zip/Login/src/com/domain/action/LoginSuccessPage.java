package com.domain.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginSuccessPage extends ActionSupport {

	
	private static final long serialVersionUID = -6031202427181693316L;
	
	
	public String execute(){
		
		Map<?, ?> session = (Map<?, ?>)	ActionContext.getContext().getSession();
		String User = (String)session.get("User");
		
		if(User== null){
			
			HttpServletRequest request = ServletActionContext.getRequest();

			HttpSession tempsession = request.getSession();
			tempsession.setMaxInactiveInterval(10);
			
			return SUCCESS;
			
		}else{
			
			return "failure";
		}
		
		
		
		
	}
	

}
