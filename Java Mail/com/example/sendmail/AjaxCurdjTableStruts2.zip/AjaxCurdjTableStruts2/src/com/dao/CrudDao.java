package com.dao;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.Gson;
import com.model.Medicine;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
public class CrudDao {

Gson gson = new Gson();







public void addMedicine(Medicine medicineObject) {
	
	MongoClient mc = new MongoClient( "localhost" , 27017 );
	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
	
	try {
		System.out
		.println(Document.parse(gson.toJson(medicineObject)).toString());
		collection.insertOne(Document.parse(gson.toJson(medicineObject)));
		
	} catch (Exception e) {
		e.printStackTrace();
		System.err.println(e.getMessage());
	}finally{
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
}







public void deleteMedicine(int userId) {
	MongoClient mc = new MongoClient( "localhost" , 27017 );
	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
	
	try {
		System.out
		.println("Delete User ID" + userId);
		collection.deleteOne(new Document("medicineID",userId));
		
	} catch (Exception e) {
		e.printStackTrace();
		System.err.println(e.getMessage());
	}finally{
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
}






public void updateMedicine(Medicine medicineObject)  {
	
	
	MongoClient mc = new MongoClient( "localhost" , 27017 );
	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
	
	try {
		System.out
		.println(medicineObject.toString());
		System.out.println(medicineObject.getMedicineCostPerUnit());
		System.out.println(Document.parse(gson.toJson(medicineObject)));

		collection.replaceOne(eq("medicineID",medicineObject.getMedicineID()), Document.parse(gson.toJson(medicineObject)));
	} catch (Exception e) {
		System.err.println(e.getMessage());
	}finally{
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
}








public List<Medicine> getAllMedicines() {
	List<Medicine> medicineObjects = new ArrayList<Medicine>();
	
	MongoClient mc = new MongoClient( "localhost" , 27017 );
	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
	 Medicine medicineObject = new Medicine();
	 Document doc; 
	 if(collection.count() > 0 ){
	 try {
		
		
		
		MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
		
		if(cursor.hasNext()){
			
			try {
		    while (cursor.hasNext()) {
		       doc =cursor.next();
		    medicineObject = gson.fromJson(doc.toJson(), Medicine.class);
		    System.out.println(" get all medi"+medicineObject.toString());
		    medicineObjects.add(medicineObject);
		    }
		} finally {
			System.out.println(medicineObjects);
		    cursor.close();
		}
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
		System.err.println(e.getMessage());
	}finally{
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
	 }else{
		 
	 }
	return medicineObjects;
}




public  Integer getUniqueUserID() {

	Integer i = 1;
	MongoClient mc = new MongoClient( "localhost" , 27017 );
	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");
	try {
		if(collection.count() == 0 )
		{
			return 1;
		}else{
			MongoCursor<Document> cursor= collection.find().sort(new BasicDBObject("medicineID",1)).iterator();;
		while (cursor.hasNext()) {

			System.out.println(" I value "+i);
			if(cursor.next().get("medicineID").equals(i)){
				i++;
			}else{
				
				cursor.close();
				break;
			}
		}
		}
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		try{ if(mc != null) {mc.close(); }} catch(Exception e ){e.printStackTrace();}
	}

	return i;
}








 public boolean hasMedicineName(String medicineName) {
	 
	 Boolean hasMedicineName = false;
	 // remove spaces and check with existing Medicine names
	

	 MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");
		try {
			if(collection.count() == 0 )
			{
				return false;
			}else{
				
				MongoCursor<Document> cursor= collection.find(new Document("medicineName",medicineName)).iterator();
				if(cursor.hasNext()){
					
					String medicineNameDB = (String)cursor.next().get("medicineName");
					cursor.close();
					System.out.println("medicineNameDB"+medicineNameDB);
					System.out.println("medicineName"+medicineName);

					if(medicineName.equals(medicineNameDB)){
						hasMedicineName = true;
					}
				}
				
				return hasMedicineName;
			}		
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{ if(mc != null) {mc.close(); }} catch(Exception e ){e.printStackTrace();}
		}
		return hasMedicineName;

		
	 
		
}




}