package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.Gson;
import com.jdbc.DataAccessObject;
import com.model.Student;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;

public class CrudDao {

private Connection dbConnection;
private PreparedStatement pStmt;
Gson gson = new Gson();
public CrudDao() {
	dbConnection = DataAccessObject.getConnection();
}

public void addStudent(Student student) {
	
	MongoClient mc = new MongoClient( "localhost" , 27017 );
	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Students");	
	
	try {
		System.out
		.println(Document.parse(gson.toJson(student)).toString());
		collection.insertOne(Document.parse(gson.toJson(student)));
		
	} catch (Exception e) {
		System.err.println(e.getMessage());
	}finally{
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
}

public void deleteStudent(int userId) {
	String deleteQuery = "DELETE FROM STUDENT WHERE STUDENTID = ?";
	try {
		pStmt = dbConnection.prepareStatement(deleteQuery);
		pStmt.setInt(1, userId);
		pStmt.executeUpdate();
	} catch (SQLException e) {
		System.err.println(e.getMessage());
	}
}

public void updateStudent(Student student)  {
	String updateQuery = "UPDATE STUDENT SET NAME = ?, " +
			"DEPARTMENT = ?, EMAIL = ? WHERE STUDENTID = ?";
	try {
		pStmt = dbConnection.prepareStatement(updateQuery);		
		pStmt.setString(1, student.getName());
		pStmt.setString(2, student.getDepartment());
		pStmt.setString(3, student.getEmailId());
		pStmt.setInt(4, student.getStudentId());
		pStmt.executeUpdate();

	} catch (SQLException e) {
		System.err.println(e.getMessage());
	}
}

public List<Student> getAllStudents() {
	List<Student> students = new ArrayList<Student>();
	
	MongoClient mc = new MongoClient( "localhost" , 27017 );
	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Students");	
	 Student student = new Student();
	 Document doc; 
	try {
		MongoCursor<Document> cursor = collection.find().iterator();
		if(cursor.hasNext()){
			
			try {
		    while (cursor.hasNext()) {
		       doc =cursor.next();
		    student = gson.fromJson(doc.toJson(), Student.class);
		    System.out.println(student.toString());
		    students.add(student);
		    }
		} finally {
		    cursor.close();
		}
		}
		
		
	} catch (Exception e) {
		System.err.println(e.getMessage());
	}finally{
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
	return students;
}
}