package com.jdbc;

import java.sql.Connection;

public class DataAccessObject {
	private static Connection connection = null;

	public static Connection getConnection() {
		
		return connection;
	}
	
}