package com.domain.action;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.Gson;
import com.model.Medicine;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.opensymphony.xwork2.ActionSupport;

public class DropAction extends ActionSupport {
	
	
	private static final long serialVersionUID = 1L;
	private List<String> dataList = null;
	private String medicineName;
	private String medicineQuantity;
	private String medicineAvailable;
	private String medicineCostPerUnit;
	private String percost;
	Gson gson = new Gson();
	

	@Override
	public String execute() throws Exception {
		/*dataList = new ArrayList<String>();
		
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("Domain").getCollection("DomainUtilities");	
		dataList =(List<String>) collection.find(new BasicDBObject("id","countrynames")).first().get("countrynames");
		
		System.out.println(dataList);*/
		
		
		/*dataList.add("India");
		dataList.add("USA");
		dataList.add("Russia");
		dataList.add("China");
		dataList.add("Japan");*/
		
		
		System.out.println("medicineName = \t"+medicineName);
		System.out.println("medicineQuantity = \t"+medicineQuantity);

		return SUCCESS;
	}

	
	public String getAvailable() throws Exception{
		
		List<Medicine> medicineObjects = new ArrayList<Medicine>();
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
		 
		 if(collection.count() > 0 ){
		 try {
			
			System.out.println(medicineName +medicineQuantity );
			
			//MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
			
			 MongoCursor<Document> cursor = null;				
				try {
					 cursor = collection.find(new Document("medicineName",medicineName)).iterator();
					 if(cursor.hasNext()){
						 
						 Document doc =cursor.next();
						String temp= (String) doc.get("medicineQuantity");
						Integer medicineAvailableDB = Integer.parseInt(temp);
						
						temp = (String) doc.get("medicineCostPerUnit");
						setMedicineCostPerUnit(temp);
						Integer cost = Integer.parseInt(medicineQuantity);
						setPercost(Integer.toString(medicineAvailableDB * cost));
						
						if(medicineAvailableDB > 0 ){
							
							if(medicineAvailableDB >= cost){
								
								setPercost(Integer.toString(medicineAvailableDB * cost));
								
							}else{
								setPercost("Enter less than "+(medicineAvailableDB+1) );
							}
							 setMedicineAvailable(Integer.toString(medicineAvailableDB));
							
						}else{
							
							 setMedicineAvailable(" No Stock ");
							
						}
						 
					 }else{
						 
						 setMedicineAvailable("No Bought");
					 }
			} finally {
				System.out.println(medicineObjects);
			    cursor.close();
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}finally{
			try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
		}
		 }else{
			 
			 
			 setMedicineAvailable(" Database has no records");
		 }
		
		
		
		return SUCCESS;
		
		
	}
	
/*	Getter and Setters*/
	public List<String> getDataList() {
		return dataList;
	}

	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}


	public String getMedicineQuantity() {
		return medicineQuantity;
	}


	public void setMedicineQuantity(String medicineQuantity) {
		this.medicineQuantity = medicineQuantity;
	}


	public String getMedicineAvailable() {
		return medicineAvailable;
	}


	public void setMedicineAvailable(String medicineAvailable) {
		this.medicineAvailable = medicineAvailable;
	}


	public String getMedicineCostPerUnit() {
		return medicineCostPerUnit;
	}


	public void setMedicineCostPerUnit(String medicineCostPerUnit) {
		this.medicineCostPerUnit = medicineCostPerUnit;
	}


	public String getPercost() {
		return percost;
	}


	public void setPercost(String percost) {
		this.percost = percost;
	}
}
