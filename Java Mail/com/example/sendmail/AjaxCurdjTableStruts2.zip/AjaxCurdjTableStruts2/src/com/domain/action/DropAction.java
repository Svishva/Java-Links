package com.domain.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.*;

import org.bson.Document;

import com.google.gson.Gson;
import com.model.Medicine;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.result.UpdateResult;
import com.opensymphony.xwork2.ActionSupport;

public class DropAction extends ActionSupport {
	
	
	private static final long serialVersionUID = 1L;
	private List<String> dataList = null;
	private String medicineName;
	private String medicineQuantity;
	private String medicineAvailable;
	private String medicineCostPerUnit;
	private String percost;
	Gson gson = new Gson();
	

	@Override
	public String execute() throws Exception {
		
		
		
		System.out.println("medicineName = \t"+medicineName);
		System.out.println("medicineQuantity = \t"+medicineQuantity);

		return SUCCESS;
	}

	
	public String getAvailable() throws Exception{
		
		List<Medicine> medicineObjects = new ArrayList<Medicine>();
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
		 
		 if(collection.count() > 0 ){
		 try {
			
			System.out.println("medicineName ="+medicineName +"medicineQuantity = "+medicineQuantity );
			
			//MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
			
			 MongoCursor<Document> cursor = null;				
				try {
					 /*cursor = collection.find(new Document("medicineName",medicineName)).iterator();
					 if(cursor.hasNext()){
						 
						 Document doc =cursor.next();
						String temp= (String) doc.get("medicineQuantity");
						BigDecimal medicineAvailableDB = BigDecimal.parseInt(temp);
						
						temp = (String) doc.get("medicineCostPerUnit");
						//setMedicineCostPerUnit(temp.replaceAll("[.]", ""));
						System.out.println("getMedicineCostPerUnit"+getMedicineCostPerUnit());
						BigDecimal cost = BigDecimal.parseInt(medicineQuantity);
						setPercost(BigDecimal.toString(medicineAvailableDB * cost));
						
						if(medicineAvailableDB > BigDecimal.ZERO ){
							
							if(medicineAvailableDB >= cost){
								
								
								BigDecimal salesMedicineQuantity = BigDecimal.parseInt(medicineQuantity);
								setPercost(BigDecimal.toString(salesMedicineQuantity * (BigDecimal.parseInt(getMedicineCostPerUnit()))));
								System.out.println("getMedicineCostPerUnit"+getMedicineCostPerUnit());
								System.out.println("salesMedicineQuantity"+salesMedicineQuantity);
							}else{
								setPercost("Enter less than "+(medicineAvailableDB+1) );
							}
							 setMedicineAvailable(BigDecimal.toString(medicineAvailableDB));
							
						}else{
							
							//if Medicine is all sold out
							setPercost(" No Stock ");
							
						}
						 
					 }else{
						 // if medicine is not present in database
						 setPercost("No Stock");
					 }*/
					
					
					if(medicineQuantity.length() >0 && medicineName.length() >1){
					
					cursor = collection.find(new Document("medicineName",medicineName)).iterator();
					 if(cursor.hasNext()){
						 Document doc =cursor.next();
						 cursor.close();
						BigDecimal quantityDB = new BigDecimal((String)doc.get("medicineQuantity"));
						BigDecimal costDB = new BigDecimal((String)doc.get("medicineCostPerUnit"));
						
						BigDecimal quantitySales = new BigDecimal(medicineQuantity);
						
						setMedicineAvailable(quantityDB.toString());
						System.out.println("comp val"+quantityDB.compareTo(quantitySales));

						if(quantityDB.compareTo(quantitySales)== -1){
							
							setPercost(quantityDB+" is available");
							
						}else{

						if(quantityDB.compareTo(BigDecimal.ZERO) == 0){
							
							setPercost("No Stock Available");
							
						}else{
							
							BigDecimal total = costDB.multiply(quantitySales);
							setPercost(total.toString());
						}
						
						}
					 }else{
						 
						 setMedicineAvailable("");
						 setPercost("No Stock Available");
					 }
					
					}
					
			} finally {
				System.out.println(medicineObjects);
			    
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}finally{
			try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
		}
		 }else{
			 
			 
			 setMedicineAvailable(" Database has no records");
		 }
		
		
		
		return SUCCESS;
		
		
	}
	
	
	
	public String postDatas(){
		
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
		
	try{	
		if(medicineName != null && medicineName.length() >0){
		
		System.out.println("post" +medicineName);
		
		
			//if(medicineQuantity.matches("\\d+") && medicineAvailable.matches("\\d+")){
				System.out.println("passed regex");
			Integer quantity = Integer.parseInt(medicineQuantity);
			Integer available = Integer.parseInt(medicineAvailable);
			if(available >= quantity){
				System.out.println("passed condition");
			Integer newQuantity = available- quantity;
				
				collection.updateOne(eq("medicineName", medicineName), new Document("$set", new Document("medicineQuantity", newQuantity.toString())));
			
			}
		//}
		}
		return SUCCESS;
	}
	catch(Exception e){
		e.printStackTrace();
		return ERROR;
	}finally{
		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
	}
		
		
		
	}
	



	/*	Getter and Setters*/
	public List<String> getDataList() {
		return dataList;
	}

	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}


	public String getMedicineQuantity() {
		return medicineQuantity;
	}


	public void setMedicineQuantity(String medicineQuantity) {
		this.medicineQuantity = medicineQuantity;
	}


	public String getMedicineAvailable() {
		return medicineAvailable;
	}


	public void setMedicineAvailable(String medicineAvailable) {
		this.medicineAvailable = medicineAvailable;
	}


	public String getMedicineCostPerUnit() {
		return medicineCostPerUnit;
	}


	public void setMedicineCostPerUnit(String medicineCostPerUnit) {
		this.medicineCostPerUnit = medicineCostPerUnit;
	}


	public String getPercost() {
		return percost;
	}


	public void setPercost(String percost) {
		this.percost = percost;
	}
}