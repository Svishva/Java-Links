package com.model;

public class Medicine {

	private int medicineID;
	private String medicineName;
	private String medicineQuantity;
	private String medicineCostPerUnit;
	
	
	/*Methods*/
	

	
	
	
	
	/*Constructors*/
	
	public Medicine(){
		
	}


	@Override
	public String toString() {
		return "Medicine [medicineID=" + medicineID + ", medicineName="
				+ medicineName + ", medicineQuantity=" + medicineQuantity
				+ ", medicineCostPerUnit=" + medicineCostPerUnit + "]";
	}





	

	/* Getter and Setters */

	


	public int getMedicineID() {
		return medicineID;
	}


	public void setMedicineID(int medicineID) {
		this.medicineID = medicineID;
	}


	public String getMedicineName() {
		return medicineName;
	}


	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}


	public String getMedicineQuantity() {
		return medicineQuantity;
	}


	public void setMedicineQuantity(String medicineQuantity) {
		this.medicineQuantity = medicineQuantity;
	}


	public String getMedicineCostPerUnit() {
		return medicineCostPerUnit;
	}


	public void setMedicineCostPerUnit(String medicineCostPerUnit) {
		this.medicineCostPerUnit = medicineCostPerUnit;
	}
	
	
	

	

}
