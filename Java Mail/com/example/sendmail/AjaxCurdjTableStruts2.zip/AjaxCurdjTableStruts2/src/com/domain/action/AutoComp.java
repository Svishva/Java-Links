package com.domain.action;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.Gson;
import com.model.Medicine;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.opensymphony.xwork2.Action;

public class AutoComp implements Action 
{
    public ArrayList<String> medicineNames = new ArrayList<String>();
    public String country;
    Gson gson = new Gson();


    public String execute() 
    {
            getMedicineNames();
            return SUCCESS;
    }

    public void getMedicineNames() 
    {
    	
    	
    	
    	MongoClient mc = new MongoClient( "localhost" , 27017 );
    	MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");	
    	
    	
    	 if(collection.count() > 0 ){
    	 try {
    		
    		
    		
    		MongoCursor<Document> cursor =collection.find().sort(new BasicDBObject("medicineID",1)).iterator();
    		
    		if(cursor.hasNext()){
    			
    			try {
    		    while (cursor.hasNext()) {
    		    	 
    		       
    		       medicineNames.add((String) cursor.next().get("medicineName"));
    		   
    		    }
    		} finally {
    			System.out.println(medicineNames);
    		    cursor.close();
    		}
    		}
    		
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    		System.err.println(e.getMessage());
    	}finally{
    		try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
    	}
    	 }else{
    		 
    	 }
            
    }

    public void setMedicineNames(ArrayList<String> medicineNames) {
		this.medicineNames = medicineNames;
	}

	public String displayCountry() 
    {
            return SUCCESS;
    }

    public String getCountry() 
    {
            return country;
    }

    public void setCountry(String country) 
    {
            this.country = country;
    }       
}
