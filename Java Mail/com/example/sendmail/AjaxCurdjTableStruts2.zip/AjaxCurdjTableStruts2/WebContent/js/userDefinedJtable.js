$(document).ready(function() {
	$('#StudentTableContainer').jtable({
		title : 'Students List',
		actions : {
			listAction : 'listAction',
			createAction : 'createAction',
			updateAction : 'updateAction',
			deleteAction : 'deleteAction'
		},

		fields : {
			studentId : {
				title : 'Student Id',
				width : '30%',
				key : true,
				list : true,
				edit : false,
				create : true
			},
			name : {
				title : 'Name',
				width : '30%',
				edit : true
				/*input: function (data) {
			       // if (data.record) {
			      //      return '<input type="text" name="Hello Name" style="width:200px" value="' + data.record.Name + '" />';
			      //  } else {
			            return '<input type="password" id="text2" name="Hello Name" style="width:200px" value="enter your name here" />';
			       // }
			    }*/
			},
			department : {
				title : 'Department',
				width : '30%',
				edit : true
			},
			emailId : {
				title : 'Email',
				width : '20%',
				edit : true
			}
		}
	});
	$('#StudentTableContainer').jtable('load');
});
