$(document).ready(function() {
	$('#StudentTableContainer').jtable({
		title : 'Medicines List',
//		sorting: true,
//		defaultSorting: 'Name ASC',
//		 paging: true, //Set paging enabled
//		 pageSize: 3,
		actions : {
			listAction : 'listAction',
			createAction : 'createAction',
			updateAction : 'updateAction',
			deleteAction : 'deleteAction'
		},

		fields : {
			medicineID : {
				title : 'Medicine ID',
				width : '15%',
				key : true,
				list : true,
				edit : false,
				create : false
			},
			medicineName : {
				title : 'Medicine Name',
				width : '30%',
				edit : true
				/*input: function (data) {
			       // if (data.record) {
			      //      return '<input type="text" name="Hello Name" style="width:200px" value="' + data.record.Name + '" />';
			      //  } else {
			            return '<input type="password" id="text2" name="Hello Name" style="width:200px" value="enter your name here" />';
			       // }
			    }*/
			},
			medicineQuantity : {
				title : 'Quantity',
				width : '30%',
				edit : true
			},
			medicineCostPerUnit : {
				title : 'Cost Per Unit',
				width : '20%',
				edit : true
			}
		}
	});
	$('#StudentTableContainer').jtable('load');
});
