package com.action;

import com.dao.CrudDao;
import com.google.gson.Gson;
import com.model.Medicine;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;
import org.bson.Document;

import static com.mongodb.client.model.Filters.eq;

import javax.servlet.http.HttpServletRequest;
public class CostCalculation extends ActionSupport{

	
	private static final long serialVersionUID = 8061441271930397590L;
	
	HttpServletRequest request;
	
	String medicineName;
	String medicineQuantity;
	String medicineAvailable;
	String medicineTotalCost;

	Medicine medicineObject;
	Gson gson = new Gson();

	private CrudDao dao = new CrudDao();
	public String execute() {
		
		MongoClient mc = new MongoClient( "localhost" , 27017 );
		MongoCollection<Document> collection = mc.getDatabase("d5").getCollection("Medicines");
		 request = ServletActionContext.getRequest();
		try {
		 for( int i=1 ; i<6 ; i++) {
			 
			 
				medicineName = request.getParameter("medicine"+i);
				medicineQuantity = request.getParameter("quantity"+i);
				medicineAvailable = request.getParameter("available"+i);
				if(medicineQuantity != null && medicineAvailable != null) {
				if(medicineName.length() > 2 && medicineQuantity.length() > 0 && medicineAvailable.length() > 0) {
					
					if(dao.hasMedicineName(medicineName)){
						
						
						
						Integer quantity = Integer.parseInt(medicineQuantity);
						Integer available = Integer.parseInt(medicineAvailable);
						if(available >= quantity){
							System.out.println("passed condition");
						Integer newQuantity = available- quantity;
							
							
						collection.updateOne(eq("medicineName", medicineName), new Document("$set", new Document("medicineQuantity", newQuantity.toString())));
						//Document doc;
					//	medicineObject = gson.fromJson(doc.toJson(), Medicine.class);
						}
						
					}
					
					
					
				}
				}
				
		 }
		 
		String a = request.getParameter("medicine1");
		String b = request.getParameter("quantity1");

		System.out.println(" a= "+a);
		System.out.println("b= "+b);
		
		return SUCCESS;
		}
		catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			try{ if(mc != null) {mc.close();}} catch(Exception e ){e.printStackTrace();}
		}
		return SUCCESS;
	}
	
}
