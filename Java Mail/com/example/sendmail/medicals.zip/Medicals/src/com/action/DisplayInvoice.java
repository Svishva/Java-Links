package com.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.model.MedicineInvoice;
import com.opensymphony.xwork2.ActionSupport;

public class DisplayInvoice extends ActionSupport{

	
	
	private static final long serialVersionUID = 8980733935103118379L;
	List<MedicineInvoice> medicineInvoiceList;
	
	@SuppressWarnings("unchecked")
	public String execute() throws Exception{
		
		HttpServletRequest request =  ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		 medicineInvoiceList =(List<MedicineInvoice>) session.getAttribute("medicineInvoiceList");
		 setMedicineInvoiceList(medicineInvoiceList);
		System.out.println(" size "+medicineInvoiceList.size());
		return SUCCESS;
		
		
	}

	public List<MedicineInvoice> getMedicineInvoiceList() {
		return medicineInvoiceList;
	}

	public void setMedicineInvoiceList(List<MedicineInvoice> medicineInvoiceList) {
		this.medicineInvoiceList = medicineInvoiceList;
	}
	
	
	
}
