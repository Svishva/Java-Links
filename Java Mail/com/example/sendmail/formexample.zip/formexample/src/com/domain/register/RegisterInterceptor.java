package com.domain.register;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.domain.dao.implementation.mongodb.MongoDBUtilities;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class RegisterInterceptor implements Interceptor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7511200971562788470L;

	@Override
	public void destroy() {

	}

	@Override
	public void init() {

	}

	@Override
	public String intercept(ActionInvocation arg0) throws Exception {

		System.out.println("RegisterInterceptor executed ");
		List<String> list = (ArrayList<String>) MongoDBUtilities
				.getAllCountryNames();

		HttpSession session = ServletActionContext.getRequest().getSession();
		if (list != null && list.size() != 0) {
			session.setAttribute("Listofcountries", list);
		}

		return "success";
	}

}
