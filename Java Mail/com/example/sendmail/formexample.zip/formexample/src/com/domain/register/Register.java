package com.domain.register;

import java.util.LinkedHashMap;
import java.util.Map;

import com.domain.dao.implementation.mongodb.MongoDBUtilities;
import com.opensymphony.xwork2.ActionSupport;

public class Register extends ActionSupport {

	private static final long serialVersionUID = -5482889523577189368L;

	private String name;
	private String password;
	private String company;
	private String nameerror;
	private String passworderror;
	private String companyerror;
	private Boolean isError = true; 
	
	private Map<String, String> stateMap = new LinkedHashMap<String, String>();

	// Parameter from Jquery
	private String countryName;
	
	


	public String execute() {
		
		//If all data passes validation tests 
		//Goto Success else show error
		
		if(isError){
			
			return SUCCESS;
			
		}else{
			
			return ERROR;
		}

		
		
	}
	
	public void	 validate() {
		
		System.out.println("Validate method executed");
		
		if(name != null && name.length() <= 6){
			setIsError(false);
			setNameerror("Name should be 7 Characters");
		}


		if(password != null && password.length() <= 6){
			setIsError(false);
			setPassworderror("Password should be 7 Characters");
		}

		
		
		
		System.out.println(toString());

	}
	
	
	
	/*
	 * call Database to get all states of a particular Country
	 * 
	 *  @param CountryName 
	 *  
	 *  @return Map<String,String> all states of Country Name
	 *  Map Key & Value are State Name
	 *  ("Tamil Nadu", "Tamil Nadu") 
	 */
	public String getstates() throws Exception {

		System.out.println("formCountryAction executed");
		
		setStateMap(new LinkedHashMap<String, String>(
				MongoDBUtilities.formCountry(countryName)));

		return SUCCESS;
	}

	
	

	
	@Override
	public String toString() {
		return "Register [name=" + name + ",\n password=" + password
				+ ",\n company=" + company + ",\n nameerror=" + nameerror
				+ ",\n passworderror=" + passworderror + ",\n companyerror="
				+ companyerror + ",\n isError=" + isError + "]";
	}

	
	

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public Boolean getIsError() {
		return isError;
	}

	public void setIsError(Boolean isError) {
		this.isError = isError;
	}
	
	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getNameerror() {
		return nameerror;
	}


	public void setNameerror(String nameerror) {
		this.nameerror = nameerror;
	}


	public String getPassworderror() {
		return passworderror;
	}


	public void setPassworderror(String passworderror) {
		this.passworderror = passworderror;
	}


	public String getCompanyerror() {
		return companyerror;
	}


	public void setCompanyerror(String companyerror) {
		this.companyerror = companyerror;
	}


	

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return password;
	}

	public void setPwd(String password) {
		this.password = password;
	}


	public String getMsg() {
		return company;
	}


	public void setMsg(String msg) {
		this.company = msg;
	}

	public Map<String, String> getStateMap() {
		return stateMap;
	}

	public void setStateMap(Map<String, String> stateMap) {
		this.stateMap = stateMap;
	}



}
