package com.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.dao.CrudDao;
import com.model.Medicine;
import com.opensymphony.xwork2.Action;

public class JtableAction {
	
	private CrudDao dao = new CrudDao();

	private List<Medicine> records;
	private String result;
	private String message;
	private Medicine record;

	private int medicineID;
	private String medicineName;
	private String medicineQuantity;
	private String medicineCostPerUnit;
	
	/*For Table Pagination*/
	
	//private Long jtStartIndex;
	//private Long jtPageSize; 
	//private Long totalRecordCount;
	
	
	
	public String list() {
		try {
			// Fetch Data from Medicine Table 
			//store in Collection (List) records
			records = new ArrayList<Medicine>();
			records = dao.getAllMedicines();
		//	setTotalRecordCount(dao.getCollectionCount());
			System.out.println(" list()"+records);
			result = "OK";
		} catch (Exception e) {
			e.printStackTrace();
			result = "ERROR";
			System.err.println(e.getMessage());
		}
		return Action.SUCCESS;
	}

	public String create() throws IOException {
		record = new Medicine();
		
		record.setMedicineID(dao.getUniqueUserID());
		record.setMedicineName(medicineName);
		record.setMedicineQuantity(medicineQuantity);
		record.setMedicineCostPerUnit(medicineCostPerUnit);
	
		try {
			
			//validate
			//Medicine Name
			if(isNull(medicineName) ) {
				
				setMessage("Enter Medicine Name");
				throw new Exception();
			}
			if(medicineName.length() <= 2) {
			
				setMessage("Please enter atleast 3 Character");
				throw new Exception();
			}
			
			if(isNull(medicineQuantity)) {
				setMessage("Enter Medicine Quantity");
				throw new Exception();
			}
			

			if(isNull(medicineCostPerUnit)) {
				setMessage("Enter Medicine Cost");
				throw new Exception();
			}
			
			
			// Create new record
			System.out.println(record.toString());
			dao.addMedicine(record);
			result = "OK";

		} catch (Exception e) {
			e.printStackTrace();
			result = "ERROR";
			
			System.err.println(e.getMessage());
		}
		return Action.SUCCESS;	
	}

	
	

	public String update() throws IOException {
		Medicine medicineObject = new Medicine();
		
		medicineObject.setMedicineID(medicineID);
		medicineObject.setMedicineName(medicineName);
		medicineObject.setMedicineQuantity(medicineQuantity);
		medicineObject.setMedicineCostPerUnit(medicineCostPerUnit);
		
		try {
			
			
			//validate
			//Medicine Name
			if(isNull(medicineName) ) {
				
				setMessage("Enter Medicine Name");
				throw new Exception();
			}
			if(medicineName.length() <= 2) {
			
				setMessage("Please enter atleast 3 Character");
				throw new Exception();
			}
			
			if(isNull(medicineQuantity)) {
				setMessage("Enter Medicine Quantity");
				throw new Exception();
			}
			

			if(isNull(medicineCostPerUnit)) {
				setMessage("Enter Medicine Cost");
				throw new Exception();
			}
			
			// Update existing record
			dao.updateMedicine(medicineObject);
			result = "OK";
			
		} catch (Exception e) {
			result = "ERROR";
			System.err.println(e.getMessage());
		}
		return Action.SUCCESS;
	}

	public String delete() throws IOException {
		// Delete a record in Database
		try {
			
			if(medicineID == 0) {
				setMessage("ID cannot be zero");
				throw new Exception();
			}
			
			//do action
			dao.deleteMedicine(medicineID);
			System.out.println(" delete Action "+medicineID);
			result = "OK";
		} catch (Exception e) {
			result = "ERROR";
			System.err.println(e.getMessage());
		}
		return Action.SUCCESS;
	}

	// Validate Methods

	
	/*
	 *  check if given parameter is null or not
	 *  @param String
	 *  @return Boolean 
	 * 		 
	 */
	private boolean isNull(String word) {

		if(word == null) {
			return true;
		}else {
			return false;
		}
		
	}
	
	
	
	/*Getter & Setter*/
	public List<Medicine> getRecords() {
		return records;
	}

	public void setRecords(List<Medicine> records) {
		this.records = records;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Medicine getRecord() {
		return record;
	}

	public void setRecord(Medicine record) {
		this.record = record;
	}

	public int getMedicineID() {
		return medicineID;
	}

	public void setMedicineID(int medicineID) {
		this.medicineID = medicineID;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	public String getMedicineQuantity() {
		return medicineQuantity;
	}

	public void setMedicineQuantity(String medicineQuantity) {
		this.medicineQuantity = medicineQuantity;
	}

	public String getMedicineCostPerUnit() {
		return medicineCostPerUnit;
	}

	public void setMedicineCostPerUnit(String medicineCostPerUnit) {
		this.medicineCostPerUnit = medicineCostPerUnit;
	}

	
	
	
	
	
	
	

	

	/*public Long getJtStartIndex() {
		return jtStartIndex;
	}

	public void setJtStartIndex(Long jtStartIndex) {
		this.jtStartIndex = jtStartIndex;
	}

	public Long getJtPageSize() {
		return jtPageSize;
	}

	public void setJtPageSize(Long jtPageSize) {
		this.jtPageSize = jtPageSize;
	}

	public Long getTotalRecordCount() {
		return totalRecordCount;
	}

	public void setTotalRecordCount(Long totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}*/

	/*Getters and Setters*/
	
	
}