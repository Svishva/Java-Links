package com.val;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.catalina.tribes.util.Arrays;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class SaveUser extends ActionSupport{

	private static final long serialVersionUID = 1L;

	 private String name;
	 
	 public String execute() 
	   {
		 Map<String, Object> parameters =  ActionContext.getContext().getParameters();
		// System.out.println(parameters);
	
		 /*for (Map.Entry<String, Object> entry : parameters.entrySet()) {
		        if(entry.getValue() instanceof String){
		             newMap.put(entry.getKey(), (String) entry.getValue());
		           }
		  }*/
		 
		/* @SuppressWarnings("unchecked")
		Map<String, String> newMap = new HashMap<String, String>((Map)parameters);
		 
		 for(Entry<String, String> entry : newMap.entrySet()){
			 
		 System.out.println("Key :" +  entry.getKey() + "\t Value :" + entry.getValue());


		 }*/
		 
		 
		 
		 for(Entry<String, Object> entry : parameters.entrySet()){
			 
			//( entry.getValue()["name"]);
	//	 System.out.println("Key :" +  entry.getKey() + "\t Value :" + Arrays.toString(entry.getValue()));

			 

		 }
		 
	       return SUCCESS;
	   }
	 
	 public String getName() {
	       return name;
	   }
	   public void setName(String name) {
	       this.name = name;
	   }
	   
	   public void validate()
	   {
	      if (name == null || name.trim().equals(""))
	      {
	         addFieldError("name","The name is required");
	      }
	      
	   }
	   
	
}
